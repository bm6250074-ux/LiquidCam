package app.glassdialer

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.telecom.PhoneAccount
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import android.telecom.VideoProfile
import android.telephony.PhoneNumberUtils
import android.widget.Toast
import androidx.core.content.ContextCompat
import java.util.Locale

data class SimAccount(val handle: PhoneAccountHandle, val label: String)

fun Context.has(permission: String): Boolean =
    ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

fun isDefaultDialer(ctx: Context): Boolean = try {
    (ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).defaultDialerPackage == ctx.packageName
} catch (_: Throwable) {
    false
}

fun simAccounts(ctx: Context): List<SimAccount> = try {
    val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
    tm.callCapablePhoneAccounts.mapNotNull { h ->
        val acc = tm.getPhoneAccount(h)
        if (acc != null && acc.hasCapabilities(PhoneAccount.CAPABILITY_SIM_SUBSCRIPTION)) {
            SimAccount(h, acc.label?.toString() ?: "SIM")
        } else null
    }
} catch (_: Throwable) {
    emptyList()
}

fun placeCall(ctx: Context, number: String, handle: PhoneAccountHandle? = null, video: Boolean = false) {
    if (number.isBlank()) return
    try {
        val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
        val extras = Bundle()
        if (handle != null) extras.putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, handle)
        if (video) extras.putInt(TelecomManager.EXTRA_START_CALL_WITH_VIDEO_STATE, VideoProfile.STATE_BIDIRECTIONAL)
        tm.placeCall(Uri.fromParts(PhoneAccount.SCHEME_TEL, number, null), extras)
    } catch (e: SecurityException) {
        Toast.makeText(ctx, "Phone permission missing", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        Toast.makeText(ctx, e.message ?: "Call failed", Toast.LENGTH_SHORT).show()
    }
}

fun safeStart(ctx: Context, intent: Intent) {
    try {
        if (ctx !is Activity) intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(ctx, "Not available", Toast.LENGTH_SHORT).show()
    }
}

fun newContactIntent(number: String): Intent =
    Intent(ContactsContract.Intents.Insert.ACTION).apply {
        type = ContactsContract.RawContacts.CONTENT_TYPE
        putExtra(ContactsContract.Intents.Insert.PHONE, number)
    }

fun addToContactIntent(number: String): Intent =
    Intent(Intent.ACTION_INSERT_OR_EDIT).apply {
        type = ContactsContract.Contacts.CONTENT_ITEM_TYPE
        putExtra(ContactsContract.Intents.Insert.PHONE, number)
    }

fun smsIntent(number: String): Intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number)))

fun prettyNumber(n: String): String {
    if (n.isEmpty() || n.contains('*') || n.contains('#')) return n
    return try {
        PhoneNumberUtils.formatNumber(n, Locale.getDefault().country) ?: n
    } catch (_: Throwable) {
        n
    }
}

fun fmtTime(sec: Long): String {
    val h = sec / 3600
    val m = (sec % 3600) / 60
    val s = sec % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
    else String.format(Locale.US, "%02d:%02d", m, s)
}

object Tones {
    private var tg: ToneGenerator? = null

    fun play(key: Char) {
        try {
            if (tg == null) tg = ToneGenerator(AudioManager.STREAM_DTMF, 70)
            val t = when (key) {
                in '0'..'9' -> ToneGenerator.TONE_DTMF_0 + (key - '0')
                '*' -> ToneGenerator.TONE_DTMF_S
                '#' -> ToneGenerator.TONE_DTMF_P
                else -> return
            }
            tg?.startTone(t, 120)
        } catch (_: Throwable) {
        }
    }
}

/** True when the screen is wider than tall (landscape layouts use compact keys, side-by-side panels, ...). */
@androidx.compose.runtime.Composable
fun isLandscape(): Boolean =
    androidx.compose.ui.platform.LocalConfiguration.current.orientation ==
        android.content.res.Configuration.ORIENTATION_LANDSCAPE
