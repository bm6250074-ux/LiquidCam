package app.glassdialer.call

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.PowerManager
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import app.glassdialer.InCallActivity

class DialerInCallService : InCallService() {

    override fun onCreate() {
        super.onCreate()
        CallManager.service = this
    }

    override fun onDestroy() {
        try {
            Notifs.cancelOngoing(this)
            Notifs.cancel(this)
        } catch (_: Throwable) {
        }
        CallManager.service = null
        super.onDestroy()
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        CallManager.add(call)
        val info = CallManager.calls.value.firstOrNull { it.call === call }
        if (CallManager.stateOf(call) == Call.STATE_RINGING) {
            // Always bring up the UI ourselves: full-screen notification intents are blocked or
            // delayed on several OEM skins (MIUI/HyperOS included), which is why the screen used
            // to stay off/locked with only the ringtone playing. The notification is still shown
            // as a backup (and for answering without unlocking when the system does allow it).
            Notifs.showIncoming(this, info?.name, info?.number ?: "")
            // Phone in use (unlocked, screen on) and none of our screens showing: only the heads-up
            // notification appears, so the user stays in the app they are using.
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            val inUse = pm.isInteractive && !km.isKeyguardLocked
            if (!inUse || CallManager.uiVisible > 0) openUi()
        } else {
            openUi()
        }
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        CallManager.remove(call)
        // Unanswered / ended calls must never leave their notification behind.
        if (CallManager.calls.value.none { it.state == Call.STATE_RINGING }) Notifs.cancel(this)
    }

    @Suppress("DEPRECATION")
    override fun onCallAudioStateChanged(audioState: CallAudioState?) {
        super.onCallAudioStateChanged(audioState)
        if (audioState != null) {
            CallManager.muted.value = audioState.isMuted
            CallManager.route.value = audioState.route
            CallManager.routeMask.value = audioState.supportedRouteMask
            CallManager.refresh()
        }
    }

    private fun openUi() {
        try {
            startActivity(Intent(this, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
        }
    }
}
