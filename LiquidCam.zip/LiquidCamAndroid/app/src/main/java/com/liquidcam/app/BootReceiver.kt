package com.liquidcam.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED && Prefs.enabled(context)) {
            // نحدّث وقت التفعيل لئلا تُعالج صور التُقطت أثناء إيقاف الجهاز دون مراقبة
            ContextCompat.startForegroundService(context, Intent(context, WatermarkService::class.java))
        }
    }
}
