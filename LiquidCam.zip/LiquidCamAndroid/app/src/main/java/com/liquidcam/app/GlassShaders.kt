package com.liquidcam.app

/**
 * شيدر "الزجاج السائل" (GLSL ES 1.00) بدون بلور وبدون تعتيم.
 * اللوحة بعرض الصورة كاملاً والحواف العليا فقط مستديرة.
 * العدسة (circleMap) والحافة اللامعة مقتبستان من مكتبة Kyant0/AndroidLiquidGlass (backdrop 2.0.0، Apache-2.0).
 * تعمل على الصور وعلى كل إطار فيديو (Live Photo).
 */
object GlassShaders {
    const val VERTEX = """
attribute vec4 aFramePosition;
uniform float uFlipY;
varying vec2 vTexCoord;
void main() {
    gl_Position = vec4(aFramePosition.x, aFramePosition.y * uFlipY, aFramePosition.z, aFramePosition.w);
    vTexCoord = aFramePosition.xy * 0.5 + 0.5;
}
"""

    const val FRAGMENT = """
precision highp float;
varying vec2 vTexCoord;
uniform sampler2D uTexSampler;
uniform sampler2D uOverlay;
uniform vec2 uSize;
uniform vec4 uBar;
uniform float uRadius;
uniform float uBevel;
uniform float uRefr;
uniform float uDisp;
uniform float uTime;
uniform float uScale;
uniform float uLight;
uniform float uFlipSample;

vec2 suv(vec2 uv) { return vec2(uv.x, mix(uv.y, 1.0 - uv.y, uFlipSample)); }
vec3 sharpAt(vec2 uv) { return texture2D(uTexSampler, suv(clamp(uv, 0.0, 1.0))).rgb; }

float sdRR(vec2 p, vec2 hs, float r) {
    vec2 q = abs(p) - (hs - r);
    return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;
}

void main() {
    vec2 uv = vTexCoord;
    vec2 px = uv * uSize;
    vec3 base = sharpAt(uv);

    float W = uSize.x;
    float barH = uBar.w;
    float R = uRadius;

    // شكل اللوحة: بعرض الصورة كاملاً، الحواف العليا فقط مستديرة (الجوانب والأسفل خارج الصورة)
    vec2 hs = vec2(W * 0.5 + 2.0, (barH + R + 2.0) * 0.5);
    vec2 p = px - vec2(W * 0.5, barH - hs.y);
    float d = sdRR(p, hs, R);
    if (d > uScale * 0.10) {
        gl_FragColor = vec4(base, 1.0);
        return;
    }
    // اتجاه الحافة: تدرّج عددي متصل (يتجنّب خطوط التقاطع القطرية)
    vec2 g = vec2(
        sdRR(p + vec2(1.0, 0.0), hs, R) - sdRR(p - vec2(1.0, 0.0), hs, R),
        sdRR(p + vec2(0.0, 1.0), hs, R) - sdRR(p - vec2(0.0, 1.0), hs, R));
    float gl2 = length(g);
    vec2 n = gl2 > 0.0001 ? g / gl2 : vec2(0.0, 1.0);
    float top = smoothstep(0.05, 0.7, n.y);

    // ظل خارجي ناعم + خط داكن رفيع يفصل اللوحة عن الصورة
    float rw = max(1.5, uScale * 0.0028);
    float sh = exp(-max(d, 0.0) / (uScale * 0.028)) * top;
    float edgeDark = exp(-pow((d - rw * 1.4) / (rw * 1.2), 2.0)) * top;
    vec3 outside = base * (1.0 - 0.07 * sh) * (1.0 - 0.06 * edgeDark);
    float alpha = 1.0 - smoothstep(-0.9, 0.9, d);
    if (alpha <= 0.0) {
        gl_FragColor = vec4(outside, 1.0);
        return;
    }

    float depth = max(-d, 0.0);
    float yN = clamp((px.y - uBar.y) / barH, 0.0, 1.0);

    // عدسة المكتبة: refractionHeight = uBevel ، refractionAmount = uRefr (circleMap)
    float u = clamp(1.0 - depth / uBevel, 0.0, 1.0);
    float dd = (depth < uBevel) ? (1.0 - sqrt(max(1.0 - u * u, 0.0))) * uRefr : 0.0;
    vec3 col = sharpAt((px - dd * n) / uSize);
    float t = u;

    // vibrancy: تشبّع أعلى (uDisp = معامل التشبّع)
    float lum = dot(col, vec3(0.299, 0.587, 0.114));
    col = mix(vec3(lum), col, uDisp);

    // جسم شفاف تماماً: بلا تعتيم، ما تحته يظهر كما هو
    col = col + 0.03 * yN;

    // حافة لامعة بأسلوب Highlight في المكتبة: |dot(grad, dir)|
    vec2 L = vec2(cos(uLight), sin(uLight));
    float dt = abs(dot(n, L));
    float lens = pow(1.0 - t, 2.2) * top;
    float edge = exp(-pow(depth / rw, 2.0));
    col += vec3(0.65 * edge * dt * (0.35 + 0.65 * top));
    col += vec3(0.22 * exp(-pow((depth - rw * 3.2) / (rw * 1.2), 2.0)) * dt * top);
    col += vec3(0.06 * lens);

    // لمعان ناعم ينزلق عبر اللوحة (يتحرك في Live Photo)
    float phase = 0.5 + 0.5 * sin(uTime * 0.7);
    float center = -0.2 + phase * 1.4;
    float cpos = px.x / uSize.x + yN * 0.25;
    col += vec3(0.08 * exp(-pow((cpos - center) / 0.08, 2.0)) * (0.3 + 0.7 * yN));
    col = clamp(col, 0.0, 1.0);

    // النص (صورة مسبقة الضرب بالشفافية)
    vec2 lp = px - uBar.xy;
    vec2 ouv = vec2(lp.x / uBar.z, 1.0 - lp.y / barH);
    vec4 ov = texture2D(uOverlay, clamp(ouv, 0.0, 1.0));
    col = col * (1.0 - ov.a) + ov.rgb;

    gl_FragColor = vec4(mix(outside, col, alpha), 1.0);
}
"""
}

/** أبعاد اللوحة السفلية الكاملة العرض، نسبة إلى الضلع الأقصر للصورة. */
class GlassParams(val w: Int, val h: Int, val compact: Boolean = false) {
    val s: Float = minOf(w, h).toFloat()
    val barH: Float = Math.round(s * (if (compact) 0.115f else 0.19f)).toFloat()
    val barW: Float = w.toFloat()
    val radius: Float = barH * (if (compact) 0.42f else 0.30f)

    /** time بالثواني؛ flipY/flipSample = -1/1 لمسار الصور الثابتة و1/0 لمسار الفيديو. */
    fun uniforms(time: Float, flipY: Float, flipSample: Float): List<Pair<String, FloatArray>> = listOf(
        "uSize" to floatArrayOf(w.toFloat(), h.toFloat()),
        "uBar" to floatArrayOf(0f, 0f, barW, barH),
        "uRadius" to floatArrayOf(radius),
        "uBevel" to floatArrayOf(barH * 0.30f),
        "uRefr" to floatArrayOf(barH * 0.50f),
        "uDisp" to floatArrayOf(1.12f),
        "uTime" to floatArrayOf(time),
        "uScale" to floatArrayOf(s),
        "uLight" to floatArrayOf(2.35f + 0.3f * Math.sin(time * 0.8).toFloat()),
        "uFlipY" to floatArrayOf(flipY),
        "uFlipSample" to floatArrayOf(flipSample)
    )
}
