package com.liquidcam.app

/**
 * شيدر "الزجاج السائل" (GLSL ES 1.00) — يُستخدم لمعالجة الصور (EGL خارج الشاشة)
 * ولمعالجة كل إطار في فيديو Live/Motion Photo (عبر Media3 Transformer).
 *
 * الفكرة: داخل كبسولة الشريط السفلي نحسب انكسار الضوء عند الحواف (عدسة محدبة)،
 * تشتتاً لونياً خفيفاً، تمويهاً للخلفية، تشبّعاً، ولمعة حافة تتحرك مع الزمن (uTime).
 * وبما أن الخلفية تُعاد قراءتها لكل إطار فيديو، فالزجاج يتفاعل مع حركة المشهد.
 */
object GlassShaders {
    const val VERTEX = """
attribute vec4 aFramePosition;
uniform float uFlipY;
varying vec2 vTexCoord;
void main() {
    gl_Position = vec4(aFramePosition.x, aFramePosition.y * uFlipY, aFramePosition.z, aFramePosition.w);
    vTexCoord = aFramePosition.xy * 0.5 + 0.5;
}
"""

    const val FRAGMENT = """
precision highp float;
varying vec2 vTexCoord;
uniform sampler2D uTexSampler;
uniform sampler2D uOverlay;
uniform vec2 uSize;
uniform vec4 uBar;
uniform float uRadius;
uniform float uBevel;
uniform float uRefr;
uniform float uDisp;
uniform float uTime;
uniform float uScale;
uniform float uBlurMix;
uniform float uBlurPx;
uniform float uLight;
uniform float uFlipSample;

vec2 suv(vec2 uv) { return vec2(uv.x, mix(uv.y, 1.0 - uv.y, uFlipSample)); }
vec3 sharpAt(vec2 uv) { return texture2D(uTexSampler, suv(clamp(uv, 0.0, 1.0))).rgb; }

float sdRR(vec2 p, vec2 hs, float r) {
    vec2 q = abs(p) - (hs - r);
    return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;
}

float ign(vec2 p) {
    return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715))));
}

vec3 blurAt(vec2 uv, vec2 frag) {
    vec3 acc = vec3(0.0);
    float rot = ign(frag) * 6.2831853;
    for (int i = 0; i < 40; i++) {
        float fi = float(i);
        float r = sqrt((fi + 0.5) / 40.0) * uBlurPx;
        float a = fi * 2.3999632 + rot;
        vec2 o = vec2(cos(a), sin(a)) * r / uSize;
        acc += sharpAt(uv + o);
    }
    return acc / 40.0;
}

void main() {
    vec2 uv = vTexCoord;
    vec2 px = uv * uSize;
    vec3 base = sharpAt(uv);

    vec2 hs = uBar.zw * 0.5;
    vec2 cen = uBar.xy + hs;
    vec2 p = px - cen;
    float d = sdRR(p, hs, uRadius);
    if (d > 1.5) {
        gl_FragColor = vec4(base, 1.0);
        return;
    }
    float depth = -d;
    float alpha = 1.0 - smoothstep(-0.9, 0.9, d);

    // الاتجاه الخارجي للحافة
    vec2 g = vec2(
        sdRR(p + vec2(1.0, 0.0), hs, uRadius) - sdRR(p - vec2(1.0, 0.0), hs, uRadius),
        sdRR(p + vec2(0.0, 1.0), hs, uRadius) - sdRR(p - vec2(0.0, 1.0), hs, uRadius));
    float gLen = length(g);
    vec2 n = gLen > 0.0001 ? g / gLen : vec2(0.0, 1.0);

    // انكسار عند الحافة (عدسة محدبة) + تموّج سائل خفيف
    float t = clamp(depth / uBevel, 0.0, 1.0);
    float lens = pow(1.0 - t, 2.2);
    float wob = 1.0 + 0.08 * sin(uTime * 2.3 + (px.x + px.y) / uScale * 9.0);
    vec2 disp = (-n) * uRefr * lens * wob;
    vec2 zoom = (cen - px) * 0.035;
    vec2 basePos = px + zoom;

    vec2 uvR = (basePos + disp * (1.0 - uDisp)) / uSize;
    vec2 uvG = (basePos + disp) / uSize;
    vec2 uvB = (basePos + disp * (1.0 + uDisp)) / uSize;

    vec3 blurred = blurAt(uvG, gl_FragCoord.xy);
    float mixv = mix(uBlurMix, uBlurMix * 0.5, lens);
    vec3 col;
    col.r = mix(sharpAt(uvR).r, blurred.r, mixv);
    col.g = mix(sharpAt(uvG).g, blurred.g, mixv);
    col.b = mix(sharpAt(uvB).b, blurred.b, mixv);

    // تشبّع وإضاءة مثل الزجاج السائل
    float lum = dot(col, vec3(0.299, 0.587, 0.114));
    col = mix(vec3(lum), col, 1.38);
    col = col * 1.04 + 0.05;

    // تعتيم تكيّفي على الخلفيات الفاتحة ليبقى النص واضحاً
    float bl = dot(blurred, vec3(0.299, 0.587, 0.114));
    col *= mix(1.0, 0.76, smoothstep(0.5, 0.9, bl));

    // لمعة الحافة المتحركة
    float rimW = max(1.5, uScale * 0.0035);
    float rim = exp(-pow(depth / (rimW * 1.6), 2.0));
    vec2 L = vec2(cos(uLight), sin(uLight));
    float facing = dot(n, L);
    float spec = rim * (pow(max(facing, 0.0), 1.6) * 0.95 + pow(max(-facing, 0.0), 1.6) * 0.5);
    float sheen = (1.0 - t) * (max(facing, 0.0) * 0.14 + max(-facing, 0.0) * 0.06);
    col += spec + sheen;

    vec2 lp = px - uBar.xy;
    col = mix(col, vec3(1.0), 0.07);
    col += 0.05 * (lp.y / uBar.w);

    float edgeLine = exp(-pow((depth - rimW * 2.4) / (rimW * 0.9), 2.0));
    col *= 1.0 - 0.10 * edgeLine;
    col = clamp(col, 0.0, 1.0);

    // النص (صورة مسبقة الضرب بالشفافية)
    vec2 ouv = vec2(lp.x / uBar.z, 1.0 - lp.y / uBar.w);
    vec4 ov = texture2D(uOverlay, clamp(ouv, 0.0, 1.0));
    col = col * (1.0 - ov.a) + ov.rgb;

    gl_FragColor = vec4(mix(base, col, alpha), 1.0);
}
"""
}

/** أبعاد الشريط والثوابت، نسبة إلى الضلع الأقصر للصورة. */
class GlassParams(val w: Int, val h: Int) {
    val s: Float = minOf(w, h).toFloat()
    val barH: Float = Math.round(s * 0.15f).toFloat()
    val margin: Float = Math.round(s * 0.035f).toFloat()
    val barW: Float = Math.round(w - 2 * margin).toFloat()

    /** time بالثواني؛ flipY/flipSample = 1 لمسار الصور الثابتة و0 لمسار الفيديو. */
    fun uniforms(time: Float, flipY: Float, flipSample: Float): List<Pair<String, FloatArray>> = listOf(
        "uSize" to floatArrayOf(w.toFloat(), h.toFloat()),
        "uBar" to floatArrayOf(margin, margin, barW, barH),
        "uRadius" to floatArrayOf(barH * 0.46f),
        "uBevel" to floatArrayOf(barH * 0.38f),
        "uRefr" to floatArrayOf(barH * 0.28f),
        "uDisp" to floatArrayOf(0.05f),
        "uTime" to floatArrayOf(time),
        "uScale" to floatArrayOf(s),
        "uBlurMix" to floatArrayOf(0.82f),
        "uBlurPx" to floatArrayOf(s * 0.022f),
        "uLight" to floatArrayOf(2.35f + 0.45f * Math.sin(time * 1.2).toFloat()),
        "uFlipY" to floatArrayOf(flipY),
        "uFlipSample" to floatArrayOf(flipSample)
    )
}
