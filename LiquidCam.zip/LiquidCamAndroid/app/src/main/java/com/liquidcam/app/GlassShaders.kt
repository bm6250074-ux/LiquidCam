package com.liquidcam.app

/**
 * شيدر "الزجاج السائل" (GLSL ES 1.00) — بدون أي بلور.
 * اللوحة ملتصقة بأسفل الصورة بعرضها كاملاً، وحوافها العليا فقط مستديرة.
 *
 * - انكسار عدسي قوي عند الحافة العليا (قطاع محدب: ميل شديد قرب الحافة) مع تشتت لوني.
 * - تكبير خفيف داخل اللوحة وتموّج سائل ناعم جداً (ثابت وبلا ضجيج، فلا يومض في الفيديو).
 * - لمعة حافة مزدوجة + وهج فرنل + لمعة تنزلق ببطء مع الزمن.
 * - لا تمويه: الصورة خلف الزجاج تبقى حادة ومنكسرة. لضمان وضوح النص نستخدم متوسط سطوع
 *   (للتعتيم فقط) من نقاط ثابتة وليس تمويهاً للصورة.
 * وبما أن الخلفية تُقرأ لكل إطار فيديو، فالزجاج يتفاعل مع حركة المشهد.
 */
object GlassShaders {
    const val VERTEX = """
attribute vec4 aFramePosition;
uniform float uFlipY;
varying vec2 vTexCoord;
void main() {
    gl_Position = vec4(aFramePosition.x, aFramePosition.y * uFlipY, aFramePosition.z, aFramePosition.w);
    vTexCoord = aFramePosition.xy * 0.5 + 0.5;
}
"""

    const val FRAGMENT = """
precision highp float;
varying vec2 vTexCoord;
uniform sampler2D uTexSampler;
uniform sampler2D uOverlay;
uniform vec2 uSize;
uniform vec4 uBar;
uniform float uRadius;
uniform float uBevel;
uniform float uRefr;
uniform float uDisp;
uniform float uTime;
uniform float uScale;
uniform float uLight;
uniform float uFlipSample;

vec2 suv(vec2 uv) { return vec2(uv.x, mix(uv.y, 1.0 - uv.y, uFlipSample)); }
vec3 sharpAt(vec2 uv) { return texture2D(uTexSampler, suv(clamp(uv, 0.0, 1.0))).rgb; }

float sdRR(vec2 p, vec2 hs, float r) {
    vec2 q = abs(p) - (hs - r);
    return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;
}

// متوسط سطوع ثابت (للتعتيم التكيّفي فقط، لا يظهر في الصورة)
float areaLum(vec2 px) {
    float acc = dot(sharpAt(px / uSize), vec3(0.299, 0.587, 0.114));
    for (int i = 0; i < 12; i++) {
        float a = float(i) * 0.5235988;
        float r = uScale * (mod(float(i), 2.0) < 0.5 ? 0.035 : 0.08);
        vec2 o = vec2(cos(a), sin(a)) * r;
        acc += dot(sharpAt((px + o) / uSize), vec3(0.299, 0.587, 0.114));
    }
    return acc / 13.0;
}

void main() {
    vec2 uv = vTexCoord;
    vec2 px = uv * uSize;
    vec3 base = sharpAt(uv);

    float barH = uBar.w;
    float R = uRadius;
    vec2 hs = vec2(uSize.x * 0.5 + 2.0, (barH + R + 2.0) * 0.5);
    vec2 cen = vec2(uSize.x * 0.5, barH - hs.y);
    vec2 p = px - cen;
    float d = sdRR(p, hs, R);
    if (d > uScale * 0.12) {
        gl_FragColor = vec4(base, 1.0);
        return;
    }

    vec2 g = vec2(
        sdRR(p + vec2(1.0, 0.0), hs, R) - sdRR(p - vec2(1.0, 0.0), hs, R),
        sdRR(p + vec2(0.0, 1.0), hs, R) - sdRR(p - vec2(0.0, 1.0), hs, R));
    float gLen = length(g);
    vec2 n = gLen > 0.0001 ? g / gLen : vec2(0.0, 1.0);
    float topMask = smoothstep(0.02, 0.6, n.y);

    // ظل خارجي ناعم فوق اللوحة يفصلها عن الصورة (إحساس الطفو)
    float sh = exp(-max(d, 0.0) / (uScale * 0.03)) * topMask;
    float rw = max(1.5, uScale * 0.0032);
    float edgeDark = exp(-pow((d - rw * 1.6) / (rw * 1.3), 2.0)) * topMask;
    vec3 outside = base * (1.0 - 0.5 * sh) * (1.0 - 0.45 * edgeDark);

    float depth = -d;
    float alpha = 1.0 - smoothstep(-0.9, 0.9, d);
    if (alpha <= 0.0) {
        gl_FragColor = vec4(outside, 1.0);
        return;
    }

    float yN = clamp((px.y - uBar.y) / barH, 0.0, 1.0);

    // ---- الانكسار العدسي (قطاع حافة محدب عريض) ----
    float t = clamp(depth / uBevel, 0.0, 1.0);
    float x = 1.0 - t;
    float slope = x / sqrt(max(1.0 - x * x, 0.03));
    float lens = clamp(slope * 0.30, 0.0, 1.0) * topMask;
    vec2 disp = (-n) * uRefr * lens;

    // انحناء سائل داخل اللوحة (موجات ناعمة متحركة) + تكبير الجسم الزجاجي
    vec2 wave = vec2(sin(px.y / uScale * 16.0 + uTime * 1.5),
                     cos(px.x / uScale * 11.0 + uTime * 1.2)) * uScale * 0.003;
    vec2 zoom = vec2((cen.x - px.x) * 0.012, (cen.y - px.y) * 0.05);
    vec2 basePos = px + zoom + wave;

    vec3 col;
    col.r = sharpAt((basePos + disp * (1.0 - uDisp)) / uSize).r;
    col.g = sharpAt((basePos + disp) / uSize).g;
    col.b = sharpAt((basePos + disp * (1.0 + uDisp)) / uSize).b;

    // ---- جسم الزجاج: صبغة حليبية شفافة + تشبّع + وضوح للنص ----
    float lum = dot(col, vec3(0.299, 0.587, 0.114));
    col = mix(vec3(lum), col, 1.4);
    col = (col - 0.5) * 1.18 + 0.5;
    float al = areaLum(px);
    col *= mix(1.0, 0.74, smoothstep(0.35, 0.85, al));
    col *= 0.92 + 0.08 * yN;

    // ---- اللمعات ----
    float rimW = max(1.5, uScale * 0.0032);
    float rim = exp(-pow(depth / rimW, 2.0)) * topMask;
    float rim2 = exp(-pow((depth - rimW * 3.6) / (rimW * 1.2), 2.0)) * topMask * 0.35;
    vec2 L = vec2(cos(uLight), sin(uLight));
    float facing = dot(n, L);
    float glow = pow(1.0 - t, 2.5) * topMask;
    float spec = rim * (0.75 + pow(max(facing, 0.0), 2.0) * 0.6) + rim2;
    col += vec3(0.96, 0.98, 1.0) * (spec * 1.1 + glow * 0.30 + lens * 0.25);

    // شريط لمعان منزلق عبر اللوحة (سمة الزجاج السائل)
    float phase = 0.5 + 0.5 * sin(uTime * 0.7);
    float center = -0.2 + phase * 1.4;
    float cpos = px.x / uSize.x + yN * 0.25;
    float band = exp(-pow((cpos - center) / 0.07, 2.0));
    col += vec3(1.0) * 0.16 * band * (0.5 + 0.5 * yN);

    // حافة سفلية داخلية داكنة خفيفة لإحساس السماكة
    col *= 1.0 - 0.10 * exp(-pow((depth - rimW * 8.0) / (rimW * 4.0), 2.0)) * topMask;
    col = clamp(col, 0.0, 1.0);

    // النص (صورة مسبقة الضرب بالشفافية)
    vec2 lp = px - uBar.xy;
    vec2 ouv = vec2(lp.x / uBar.z, 1.0 - lp.y / barH);
    vec4 ov = texture2D(uOverlay, clamp(ouv, 0.0, 1.0));
    col = col * (1.0 - ov.a) + ov.rgb;

    gl_FragColor = vec4(mix(outside, col, alpha), 1.0);
}
"""
}

/** أبعاد اللوحة السفلية الكاملة العرض، نسبة إلى الضلع الأقصر للصورة. */
class GlassParams(val w: Int, val h: Int, val compact: Boolean = false) {
    val s: Float = minOf(w, h).toFloat()
    val barH: Float = Math.round(s * (if (compact) 0.115f else 0.19f)).toFloat()
    val barW: Float = w.toFloat()
    val radius: Float = barH * (if (compact) 0.42f else 0.30f)

    /** time بالثواني؛ flipY/flipSample = -1/1 لمسار الصور الثابتة و1/0 لمسار الفيديو. */
    fun uniforms(time: Float, flipY: Float, flipSample: Float): List<Pair<String, FloatArray>> = listOf(
        "uSize" to floatArrayOf(w.toFloat(), h.toFloat()),
        "uBar" to floatArrayOf(0f, 0f, barW, barH),
        "uRadius" to floatArrayOf(radius),
        "uBevel" to floatArrayOf(barH * 0.34f),
        "uRefr" to floatArrayOf(barH * 0.42f),
        "uDisp" to floatArrayOf(0.2f),
        "uTime" to floatArrayOf(time),
        "uScale" to floatArrayOf(s),
        "uLight" to floatArrayOf(2.35f + 0.3f * Math.sin(time * 0.8).toFloat()),
        "uFlipY" to floatArrayOf(flipY),
        "uFlipSample" to floatArrayOf(flipSample)
    )
}
