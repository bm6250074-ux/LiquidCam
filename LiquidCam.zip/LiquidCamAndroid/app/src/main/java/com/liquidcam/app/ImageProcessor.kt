package com.liquidcam.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.MediaScannerConnection
import androidx.exifinterface.media.ExifInterface
import java.io.ByteArrayOutputStream
import java.io.File

object ImageProcessor {
    const val MARKER = "LiquidCamWM"

    private val COPY_TAGS = listOf(
        ExifInterface.TAG_MAKE, ExifInterface.TAG_MODEL, ExifInterface.TAG_DATETIME,
        ExifInterface.TAG_DATETIME_ORIGINAL, ExifInterface.TAG_DATETIME_DIGITIZED,
        ExifInterface.TAG_SUBSEC_TIME, ExifInterface.TAG_SUBSEC_TIME_ORIGINAL, ExifInterface.TAG_SUBSEC_TIME_DIGITIZED,
        ExifInterface.TAG_OFFSET_TIME, ExifInterface.TAG_OFFSET_TIME_ORIGINAL, ExifInterface.TAG_OFFSET_TIME_DIGITIZED,
        ExifInterface.TAG_F_NUMBER, ExifInterface.TAG_EXPOSURE_TIME, ExifInterface.TAG_PHOTOGRAPHIC_SENSITIVITY,
        ExifInterface.TAG_FOCAL_LENGTH, ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM,
        ExifInterface.TAG_EXPOSURE_BIAS_VALUE, ExifInterface.TAG_FLASH, ExifInterface.TAG_WHITE_BALANCE,
        ExifInterface.TAG_LENS_MODEL, ExifInterface.TAG_LENS_MAKE, ExifInterface.TAG_SOFTWARE
    )

    /** يرجع true إذا عُولجت الصورة، false إذا تُجوّزت (معالجة سابقاً أو ليست JPEG صالحة). */
    suspend fun process(ctx: Context, file: File): Boolean {
        val original = file.readBytes()
        val originalMod = file.lastModified()
        val split = MotionPhoto.split(original)
        val jpegBytes = split?.jpeg ?: original

        val tmpSrc = File(ctx.cacheDir, "lc_src.jpg")
        tmpSrc.writeBytes(jpegBytes)
        val exif = ExifInterface(tmpSrc.absolutePath)
        if (exif.getAttribute(ExifInterface.TAG_USER_COMMENT)?.contains(MARKER) == true) return false

        val orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        val info = WatermarkInfo.from(ctx, exif, originalMod)

        val opts = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 }
        var bmp = BitmapFactory.decodeByteArray(jpegBytes, 0, jpegBytes.size, opts) ?: return false
        bmp = applyOrientation(bmp, orientation)
        bmp = capSize(bmp, StillRenderer.MAX_SIDE)

        val params = GlassParams(bmp.width, bmp.height)
        val overlay = Overlay.make(info, params)
        val rendered = StillRenderer.render(bmp, params, overlay, 0f)
        bmp.recycle()
        overlay.recycle()

        val jpegOut = ByteArrayOutputStream(jpegBytes.size)
        rendered.compress(Bitmap.CompressFormat.JPEG, 95, jpegOut)
        val rw = rendered.width
        val rh = rendered.height
        rendered.recycle()

        val tmpOut = File(ctx.cacheDir, "lc_out.jpg")
        tmpOut.writeBytes(jpegOut.toByteArray())
        copyExif(exif, tmpOut, rw, rh)
        val finalJpeg = tmpOut.readBytes()

        var finalBytes = finalJpeg
        if (split != null) {
            var video = split.video
            if (Prefs.video(ctx)) {
                try {
                    val vin = File(ctx.cacheDir, "lc_in.mp4")
                    val vout = File(ctx.cacheDir, "lc_out.mp4")
                    vin.writeBytes(split.video)
                    VideoGlass.process(ctx, vin, vout, info)
                    video = MotionPhoto.trimMp4(vout.readBytes())
                    vin.delete()
                    vout.delete()
                } catch (e: Exception) {
                    // إن فشل الفيديو نُبقي الفيديو الأصلي ليبقى Live Photo يعمل
                    Prefs.setLog(ctx, "video: ${e.javaClass.simpleName}: ${e.message}")
                }
            }
            finalBytes = MotionPhoto.build(finalJpeg, video, split.presentationUs)
        }

        file.outputStream().use { it.write(finalBytes) }
        file.setLastModified(originalMod)
        MediaScannerConnection.scanFile(ctx, arrayOf(file.absolutePath), arrayOf("image/jpeg"), null)
        tmpSrc.delete()
        tmpOut.delete()
        return true
    }

    private fun copyExif(src: ExifInterface, outFile: File, w: Int, h: Int) {
        val dst = ExifInterface(outFile.absolutePath)
        for (tag in COPY_TAGS) src.getAttribute(tag)?.let { dst.setAttribute(tag, it) }
        src.latLong?.let { dst.setLatLong(it[0], it[1]) }
        if (src.hasAttribute(ExifInterface.TAG_GPS_ALTITUDE)) {
            dst.setAltitude(src.getAltitude(0.0))
        }
        dst.setAttribute(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL.toString())
        dst.setAttribute(ExifInterface.TAG_PIXEL_X_DIMENSION, w.toString())
        dst.setAttribute(ExifInterface.TAG_PIXEL_Y_DIMENSION, h.toString())
        dst.setAttribute(ExifInterface.TAG_USER_COMMENT, MARKER)
        dst.saveAttributes()
    }

    private fun applyOrientation(b: Bitmap, o: Int): Bitmap {
        val m = Matrix()
        when (o) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
            else -> return b
        }
        val r = Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
        if (r !== b) b.recycle()
        return r
    }

    private fun capSize(b: Bitmap, max: Int): Bitmap {
        val longest = maxOf(b.width, b.height)
        if (longest <= max) return b
        val k = max.toFloat() / longest
        val r = Bitmap.createScaledBitmap(b, Math.round(b.width * k), Math.round(b.height * k), true)
        if (r !== b) b.recycle()
        return r
    }
}
