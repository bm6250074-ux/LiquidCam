package com.liquidcam.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : Activity() {
    // الألوان
    private val bg1 = Color.parseColor("#070A14")
    private val bg2 = Color.parseColor("#12183A")
    private val accent = Color.parseColor("#6C8CFF")
    private val accent2 = Color.parseColor("#B27CFF")
    private val ok = Color.parseColor("#3DDC97")
    private val textMain = Color.WHITE
    private val textDim = Color.parseColor("#A9B0C9")

    private class Step(val dot: View, val btn: Button, val check: () -> Boolean)

    private val steps = mutableListOf<Step>()
    private lateinit var master: Switch
    private lateinit var stateText: TextView
    private lateinit var stateDot: View
    private lateinit var logText: TextView
    private val scope = CoroutineScope(Dispatchers.Main)

    private fun dp(v: Int) = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    private fun rounded(color: Int, radius: Int, strokeColor: Int = 0, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke > 0) setStroke(dp(stroke), strokeColor)
    }

    private fun gradient(c1: Int, c2: Int, radius: Int) = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(c1, c2)).apply {
        cornerRadius = dp(radius).toFloat()
    }

    private fun text(t: String, size: Float, color: Int = textMain, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(Color.parseColor("#1AFFFFFF"), 22, Color.parseColor("#2EFFFFFF"), 1)
        setPadding(dp(18), dp(16), dp(18), dp(16))
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(14) }
    }

    private fun sectionTitle(t: String) = text(t, 13f, textDim, true).apply {
        letterSpacing = 0.08f
        setPadding(dp(4), dp(22), dp(4), 0)
    }

    private fun pillButton(label: String, filled: Boolean, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 14f
        setTextColor(textMain)
        setTypeface(typeface, Typeface.BOLD)
        stateListAnimator = null
        background = if (filled) gradient(accent, accent2, 24)
        else rounded(Color.parseColor("#26FFFFFF"), 24, Color.parseColor("#33FFFFFF"), 1)
        setPadding(dp(18), 0, dp(18), 0)
        minHeight = dp(44)
        minimumHeight = dp(44)
        setOnClickListener { onClick() }
    }

    private fun toggleRow(title: String, sub: String?, initial: Boolean, onChange: (Boolean) -> Unit): Pair<LinearLayout, Switch> {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        col.addView(text(title, 15f))
        if (sub != null) col.addView(text(sub, 12f, textDim))
        val sw = Switch(this).apply {
            isChecked = initial
            thumbTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(Color.WHITE, Color.parseColor("#C9CEE0"))
            )
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(accent, Color.parseColor("#3A4062"))
            )
            setOnCheckedChangeListener { _, v -> onChange(v) }
        }
        row.addView(col)
        row.addView(sw)
        return row to sw
    }

    private fun field(hint: String, value: String, onChange: (String) -> Unit) = EditText(this).apply {
        this.hint = hint
        setText(value)
        setSingleLine()
        inputType = InputType.TYPE_CLASS_TEXT
        setTextColor(textMain)
        setHintTextColor(Color.parseColor("#6D7596"))
        textSize = 15f
        background = rounded(Color.parseColor("#22000000"), 14, Color.parseColor("#2EFFFFFF"), 1)
        setPadding(dp(14), dp(12), dp(14), dp(12))
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(6); bottomMargin = dp(6) }
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = onChange(s?.toString() ?: "")
        })
    }

    private fun stepRow(num: Int, title: String, desc: String, action: String, check: () -> Boolean, onClick: () -> Unit): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        val dot = TextView(this).apply {
            text = num.toString()
            gravity = Gravity.CENTER
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(textMain)
            layoutParams = LinearLayout.LayoutParams(dp(32), dp(32)).apply { marginEnd = dp(12) }
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        col.addView(text(title, 15f, textMain, true))
        col.addView(text(desc, 12f, textDim))
        val btn = pillButton(action, false, onClick).apply { minHeight = dp(38); minimumHeight = dp(38); textSize = 12f }
        row.addView(dot)
        row.addView(col)
        row.addView(btn)
        steps.add(Step(dot, btn, check))
        return row
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val page = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(bg1, bg2, bg1))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(28))
        }
        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(root)
            setOnApplyWindowInsetsListener { v, insets ->
                val i = insets.getInsets(WindowInsets.Type.systemBars())
                v.setPadding(0, i.top, 0, i.bottom)
                insets
            }
        }
        page.addView(scroll)
        setContentView(page)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        window.insetsController?.setSystemBarsAppearance(
            0,
            WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        )

        // ---------- الشعار والعنوان ----------
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(16), 0, dp(8))
        }
        val orb = TextView(this).apply {
            text = "IN"
            gravity = Gravity.CENTER
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            letterSpacing = 0.05f
            val core = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(accent, accent2)).apply { shape = GradientDrawable.OVAL }
            val ring = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.TRANSPARENT)
                setStroke(dp(2), Color.parseColor("#66FFFFFF"))
            }
            background = LayerDrawable(arrayOf(core, ring))
            layoutParams = LinearLayout.LayoutParams(dp(56), dp(56)).apply { marginEnd = dp(14) }
        }
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(text("IN-LiquidMark", 26f, textMain, true))
        titles.addView(text("Liquid Glass Watermark", 13f, textDim).apply { letterSpacing = 0.06f })
        header.addView(orb)
        header.addView(titles)
        root.addView(header)

        // ---------- بطاقة التشغيل الرئيسية ----------
        val main = card()
        val stateRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        stateDot = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(10), dp(10)).apply { marginEnd = dp(8) }
        }
        stateText = text("", 13f, textDim, true)
        stateRow.addView(stateDot)
        stateRow.addView(stateText)
        main.addView(stateRow)
        val (mRow, mSw) = toggleRow(
            "الحماية التلقائية",
            "كل صورة جديدة من الكاميرا تحصل على لوحة الزجاج السائل",
            Prefs.enabled(this)
        ) { on ->
            if (on) {
                if (!hasAllFiles()) {
                    Toast.makeText(this, "فعّل الخطوة 1 أولاً", Toast.LENGTH_LONG).show()
                    master.isChecked = false
                    return@toggleRow
                }
                Prefs.setEnabledAt(this, System.currentTimeMillis())
                Prefs.setEnabled(this, true)
                ContextCompat.startForegroundService(this, Intent(this, WatermarkService::class.java))
            } else {
                Prefs.setEnabled(this, false)
                stopService(Intent(this, WatermarkService::class.java))
            }
            refresh()
        }
        master = mSw
        main.addView(mRow)
        logText = text("", 12f, textDim)
        main.addView(logText)
        root.addView(main)

        // ---------- الإعداد ----------
        root.addView(sectionTitle("SETUP · الإعداد (مرة واحدة)"))
        val setup = card()
        setup.addView(stepRow(1, "الوصول لكل الملفات", "لاستبدال الصورة الأصلية بالنسخة الجديدة", "فتح", { hasAllFiles() }) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        setup.addView(stepRow(2, "الصور والإشعارات", "لقراءة الصور وإظهار إشعار الخدمة", "السماح", { hasMediaPerms() }) {
            val perms = mutableListOf<String>()
            if (Build.VERSION.SDK_INT >= 33) {
                perms.add(Manifest.permission.READ_MEDIA_IMAGES)
                perms.add(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
            requestPermissions(perms.toTypedArray(), 1)
        })
        setup.addView(stepRow(3, "استثناء البطارية", "حتى لا يوقف النظام الخدمة (مهم للاستقرار)", "استثناء", { batteryOk() }) {
            if (!batteryOk()) {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
            }
        })
        root.addView(setup)

        // ---------- التخصيص ----------
        root.addView(sectionTitle("CUSTOMIZE · التخصيص"))
        val custom = card()
        custom.addView(text("اسم الهاتف في اللوحة", 13f, textDim))
        custom.addView(field(WatermarkInfo.deviceName(this), Prefs.name(this)) { Prefs.setName(this, it) })
        custom.addView(text("مجلد صور الكاميرا", 13f, textDim))
        custom.addView(field("DCIM/Camera", Prefs.folder(this)) { Prefs.setFolder(this, it.ifBlank { "DCIM/Camera" }) })
        custom.addView(toggleRow("مواصفات الصورة", "العدسة، الفتحة، الغالق، ISO، الحجم", Prefs.specs(this)) { Prefs.setSpecs(this, it) }.first)
        custom.addView(toggleRow("التاريخ والوقت", null, Prefs.date(this)) { Prefs.setDate(this, it) }.first)
        custom.addView(toggleRow("زجاج متحرك في Live Photo", "معالجة فيديو الصورة المتحركة إطاراً بإطار", Prefs.video(this)) { Prefs.setVideo(this, it) }.first)
        root.addView(custom)

        // ---------- تجربة ----------
        val test = pillButton("جرّب الآن على آخر صورة من الكاميرا", true) {
            if (!hasAllFiles()) {
                Toast.makeText(this, "فعّل الخطوة 1 أولاً", Toast.LENGTH_LONG).show()
                return@pillButton
            }
            logText.text = "جارٍ المعالجة…"
            scope.launch {
                val n = withContext(Dispatchers.Default) { Scanner.scan(this@MainActivity, force = true) }
                Toast.makeText(
                    this@MainActivity,
                    if (n > 0) "تمت المعالجة ✓" else "لا توجد صورة جديدة (أو عولجت سابقاً)",
                    Toast.LENGTH_LONG
                ).show()
                refresh()
            }
        }.apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52)
            ).apply { topMargin = dp(20) }
        }
        root.addView(test)

        // ---------- الحقوق ----------
        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(32), 0, dp(4))
        }
        footer.addView(View(this).apply {
            background = gradient(Color.TRANSPARENT, Color.TRANSPARENT, 0).apply {
                colors = intArrayOf(Color.TRANSPARENT, Color.parseColor("#55FFFFFF"), Color.TRANSPARENT)
            }
            layoutParams = LinearLayout.LayoutParams(dp(120), dp(1)).apply { bottomMargin = dp(14) }
        })
        footer.addView(text("© 2026 Incertus", 14f, textMain, true).apply { letterSpacing = 0.1f })
        footer.addView(text("All rights reserved", 11f, textDim).apply { setPadding(0, dp(2), 0, 0) })
        root.addView(footer)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun hasAllFiles(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager() else true

    private fun hasMediaPerms(): Boolean {
        val media = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE
        val notif = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        return checkSelfPermission(media) == PackageManager.PERMISSION_GRANTED && notif
    }

    private fun batteryOk(): Boolean =
        getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)

    private fun refresh() {
        for (s in steps) {
            val done = s.check()
            s.dot.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(if (done) ok else Color.parseColor("#33FFFFFF"))
            }
            (s.dot as TextView).setTextColor(if (done) Color.parseColor("#06210F") else textMain)
            s.btn.alpha = if (done) 0.45f else 1f
        }
        val running = Prefs.enabled(this)
        stateDot.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (running) ok else Color.parseColor("#6D7596"))
        }
        stateText.text = if (running) "RUNNING · يراقب صور الكاميرا" else "STOPPED · متوقف"
        stateText.setTextColor(if (running) ok else textDim)
        val log = Prefs.log(this)
        logText.text = if (log.isNotEmpty()) "آخر حدث: $log" else ""
        logText.visibility = if (log.isNotEmpty()) View.VISIBLE else View.GONE
    }
}
