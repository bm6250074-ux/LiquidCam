package com.liquidcam.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var master: Switch
    private val scope = CoroutineScope(Dispatchers.Main)

    private fun dp(v: Int) = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    private fun label(text: String, size: Float = 15f, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = size
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(8), 0, dp(4))
    }

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun toggle(text: String, initial: Boolean, onChange: (Boolean) -> Unit) = Switch(this).apply {
        this.text = text
        isChecked = initial
        setPadding(0, dp(8), 0, dp(8))
        setOnCheckedChangeListener { _, v -> onChange(v) }
    }

    private fun field(hint: String, value: String, onChange: (String) -> Unit) = EditText(this).apply {
        this.hint = hint
        setText(value)
        setSingleLine()
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = onChange(s?.toString() ?: "")
        })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(40), dp(20), dp(24))
        }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)

        root.addView(label("LiquidCam", 26f, true))
        root.addView(label("يضيف شريط زجاج سائل تلقائياً لكل صورة جديدة من كاميرا الهاتف (عادية أو Live/Motion Photo)."))

        status = label("", 14f)
        root.addView(status)

        root.addView(label("الخطوات (مرة واحدة)", 17f, true))
        root.addView(button("1) السماح بالوصول لكل الملفات") {
            val i = if (Build.VERSION.SDK_INT >= 30)
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
            else Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            startActivity(i)
        })
        root.addView(button("2) السماح بالصور والإشعارات") {
            val perms = mutableListOf<String>()
            if (Build.VERSION.SDK_INT >= 33) {
                perms.add(Manifest.permission.READ_MEDIA_IMAGES)
                perms.add(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
            requestPermissions(perms.toTypedArray(), 1)
        })
        root.addView(button("3) استثناء من توفير البطارية (مهم)") {
            val pm = getSystemService(PowerManager::class.java)
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
            } else {
                Toast.makeText(this, "مفعّل مسبقاً", Toast.LENGTH_SHORT).show()
            }
        })

        master = toggle("تفعيل العلامة المائية التلقائية", Prefs.enabled(this)) { on ->
            if (on) {
                if (!hasAllFiles()) {
                    Toast.makeText(this, "فعّل الخطوة 1 أولاً", Toast.LENGTH_LONG).show()
                    master.isChecked = false
                    return@toggle
                }
                Prefs.setEnabledAt(this, System.currentTimeMillis())
                Prefs.setEnabled(this, true)
                ContextCompat.startForegroundService(this, Intent(this, WatermarkService::class.java))
            } else {
                Prefs.setEnabled(this, false)
                stopService(Intent(this, WatermarkService::class.java))
            }
            refresh()
        }
        root.addView(master)

        root.addView(label("الإعدادات", 17f, true))
        root.addView(label("اسم الهاتف في الشريط (فارغ = تلقائي)"))
        root.addView(field(WatermarkInfo.deviceName(this), Prefs.name(this)) { Prefs.setName(this, it) })
        root.addView(label("مجلد صور الكاميرا"))
        root.addView(field("DCIM/Camera", Prefs.folder(this)) { Prefs.setFolder(this, it.ifBlank { "DCIM/Camera" }) })
        root.addView(toggle("إظهار مواصفات الصورة (العدسة، الفتحة، ISO)", Prefs.specs(this)) { Prefs.setSpecs(this, it) })
        root.addView(toggle("إظهار التاريخ والوقت", Prefs.date(this)) { Prefs.setDate(this, it) })
        root.addView(toggle("معالجة فيديو Live/Motion Photo (زجاج متحرك)", Prefs.video(this)) { Prefs.setVideo(this, it) })

        root.addView(label("تجربة", 17f, true))
        root.addView(button("معالجة آخر صورة من الكاميرا الآن") {
            if (!hasAllFiles()) {
                Toast.makeText(this, "فعّل الخطوة 1 أولاً", Toast.LENGTH_LONG).show()
                return@button
            }
            status.text = "جارٍ المعالجة…"
            scope.launch {
                val n = withContext(Dispatchers.Default) { Scanner.scan(this@MainActivity, force = true) }
                Toast.makeText(
                    this@MainActivity,
                    if (n > 0) "تمت المعالجة" else "لا توجد صورة جديدة (أو عولجت سابقاً)",
                    Toast.LENGTH_LONG
                ).show()
                refresh()
            }
        })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun hasAllFiles(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager() else true

    private fun refresh() {
        val sb = StringBuilder()
        sb.append(if (hasAllFiles()) "✓ الوصول للملفات" else "✗ الوصول للملفات (الخطوة 1)").append('\n')
        sb.append(if (Prefs.enabled(this)) "✓ الخدمة تعمل" else "○ الخدمة متوقفة").append('\n')
        val log = Prefs.log(this)
        if (log.isNotEmpty()) sb.append("آخر حدث: ").append(log)
        status.text = sb.toString()
        status.visibility = View.VISIBLE
        status.gravity = Gravity.START
    }
}
