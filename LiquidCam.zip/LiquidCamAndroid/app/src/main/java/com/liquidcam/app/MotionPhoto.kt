package com.liquidcam.app

import java.io.ByteArrayOutputStream

/**
 * Live Photo في أندرويد = "Motion Photo": ملف JPEG يلتصق به فيديو MP4 قصير في النهاية،
 * ووصفه في XMP (صيغة Google، وسامسونج الحديثة تتبعها أيضاً).
 */
object MotionPhoto {
    class Split(val jpeg: ByteArray, val video: ByteArray, val presentationUs: Long)

    private val XMP_HEADER = "http://ns.adobe.com/xap/1.0/\u0000".toByteArray(Charsets.ISO_8859_1)

    fun split(bytes: ByteArray): Split? {
        if (bytes.size < 1000) return null
        val head = String(bytes, 0, minOf(bytes.size, 262144), Charsets.ISO_8859_1)
        if (!head.contains("MotionPhoto") && !head.contains("MicroVideo")) return null

        var start = -1
        Regex("""MicroVideoOffset\s*=\s*"(\d+)"""").find(head)?.groupValues?.get(1)?.toIntOrNull()?.let {
            start = bytes.size - it
        }
        if (!isMp4At(bytes, start)) {
            start = -1
            val m = Regex("""Item:Mime="video/mp4"[^>]*?Item:Length="(\d+)"""").find(head)
                ?: Regex("""Item:Length="(\d+)"[^>]*?Item:Mime="video/mp4"""").find(head)
            m?.groupValues?.get(1)?.toIntOrNull()?.let { start = bytes.size - it }
        }
        if (!isMp4At(bytes, start)) {
            start = -1
            var i = 12
            while (i < bytes.size - 8) {
                if (bytes[i] == 'f'.code.toByte() && bytes[i + 1] == 't'.code.toByte() &&
                    bytes[i + 2] == 'y'.code.toByte() && bytes[i + 3] == 'p'.code.toByte()
                ) {
                    val size = readInt(bytes, i - 4)
                    if (size in 16..64) {
                        start = i - 4
                        break
                    }
                }
                i++
            }
        }
        if (!isMp4At(bytes, start)) return null

        val ts = Regex("""PresentationTimestampUs\s*=\s*"(-?\d+)"""").find(head)?.groupValues?.get(1)?.toLongOrNull() ?: -1L
        val video = trimMp4(bytes.copyOfRange(start, bytes.size))
        return Split(bytes.copyOfRange(0, start), video, ts)
    }

    private fun isMp4At(b: ByteArray, start: Int): Boolean {
        if (start < 4 || start + 8 > b.size) return false
        return b[start + 4] == 'f'.code.toByte() && b[start + 5] == 't'.code.toByte() &&
            b[start + 6] == 'y'.code.toByte() && b[start + 7] == 'p'.code.toByte()
    }

    private fun readInt(b: ByteArray, o: Int): Int {
        if (o < 0 || o + 4 > b.size) return -1
        return ((b[o].toInt() and 0xFF) shl 24) or ((b[o + 1].toInt() and 0xFF) shl 16) or
            ((b[o + 2].toInt() and 0xFF) shl 8) or (b[o + 3].toInt() and 0xFF)
    }

    /** يقصّ أي بيانات زائدة (مثل ذيل سامسونج) بعد آخر صندوق MP4 صالح. */
    fun trimMp4(b: ByteArray): ByteArray {
        var pos = 0
        while (pos + 8 <= b.size) {
            var size = readInt(b, pos).toLong() and 0xFFFFFFFFL
            val t = b.copyOfRange(pos + 4, pos + 8)
            if (t.any { it < 0x20 || it > 0x7E }) break
            if (size == 1L) {
                if (pos + 16 > b.size) break
                size = (readInt(b, pos + 8).toLong() shl 32) or (readInt(b, pos + 12).toLong() and 0xFFFFFFFFL)
            } else if (size == 0L) {
                return b
            }
            if (size < 8 || pos + size > b.size) break
            pos += size.toInt()
        }
        return if (pos > 0) b.copyOfRange(0, pos) else b
    }

    fun build(jpeg: ByteArray, video: ByteArray, presentationUs: Long): ByteArray {
        val withXmp = insertXmp(jpeg, xmpPacket(video.size, presentationUs))
        val out = ByteArrayOutputStream(withXmp.size + video.size)
        out.write(withXmp)
        out.write(video)
        return out.toByteArray()
    }

    private fun xmpPacket(videoLen: Int, ts: Long): ByteArray {
        val xmp = """<?xpacket begin="" id="W5M0MpCehiHzreSzNTczkc9d"?>
<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="LiquidCam">
<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
<rdf:Description rdf:about=""
 xmlns:GCamera="http://ns.google.com/photos/1.0/camera/"
 xmlns:Container="http://ns.google.com/photos/1.0/container/"
 xmlns:Item="http://ns.google.com/photos/1.0/container/item/"
 GCamera:MotionPhoto="1"
 GCamera:MotionPhotoVersion="1"
 GCamera:MotionPhotoPresentationTimestampUs="$ts"
 GCamera:MicroVideo="1"
 GCamera:MicroVideoVersion="1"
 GCamera:MicroVideoOffset="$videoLen"
 GCamera:MicroVideoPresentationTimestampUs="$ts">
<Container:Directory>
<rdf:Seq>
<rdf:li rdf:parseType="Resource"><Container:Item Item:Mime="image/jpeg" Item:Semantic="Primary" Item:Length="0" Item:Padding="0"/></rdf:li>
<rdf:li rdf:parseType="Resource"><Container:Item Item:Mime="video/mp4" Item:Semantic="MotionPhoto" Item:Length="$videoLen" Item:Padding="0"/></rdf:li>
</rdf:Seq>
</Container:Directory>
</rdf:Description>
</rdf:RDF>
</x:xmpmeta>
<?xpacket end="w"?>"""
        return xmp.toByteArray(Charsets.UTF_8)
    }

    private fun startsWith(b: ByteArray, off: Int, prefix: ByteArray): Boolean {
        if (off + prefix.size > b.size) return false
        for (i in prefix.indices) if (b[off + i] != prefix[i]) return false
        return true
    }

    /** يحذف أي XMP قديم من JPEG ويدرج الجديد بعد مقاطع APPn الأولى. */
    private fun insertXmp(jpeg: ByteArray, xmp: ByteArray): ByteArray {
        val out = ByteArrayOutputStream(jpeg.size + xmp.size + 64)
        if (jpeg.size < 4 || jpeg[0] != 0xFF.toByte() || jpeg[1] != 0xD8.toByte()) return jpeg
        out.write(0xFF)
        out.write(0xD8)

        fun writeXmp() {
            val len = 2 + XMP_HEADER.size + xmp.size
            out.write(0xFF)
            out.write(0xE1)
            out.write((len shr 8) and 0xFF)
            out.write(len and 0xFF)
            out.write(XMP_HEADER)
            out.write(xmp)
        }

        var pos = 2
        var inserted = false
        while (pos + 4 <= jpeg.size) {
            if (jpeg[pos] != 0xFF.toByte()) break
            val marker = jpeg[pos + 1].toInt() and 0xFF
            if (marker == 0xDA || marker == 0xD9) break
            val len = ((jpeg[pos + 2].toInt() and 0xFF) shl 8) or (jpeg[pos + 3].toInt() and 0xFF)
            val segEnd = pos + 2 + len
            if (segEnd > jpeg.size) break
            val isApp = marker in 0xE0..0xEF
            if (!isApp && !inserted) {
                writeXmp()
                inserted = true
            }
            val isXmp = marker == 0xE1 && startsWith(jpeg, pos + 4, XMP_HEADER)
            if (!isXmp) out.write(jpeg, pos, segEnd - pos)
            pos = segEnd
        }
        if (!inserted) writeXmp()
        out.write(jpeg, pos, jpeg.size - pos)
        return out.toByteArray()
    }
}
