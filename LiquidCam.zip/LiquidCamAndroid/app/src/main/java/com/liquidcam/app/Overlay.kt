package com.liquidcam.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface

/**
 * محتوى اللوحة السفلية (شفاف) بحجمها بالضبط:
 *  - صف علوي: "Shot on <الهاتف>" (+ شارة LIVE) يميناً التاريخ والوقت.
 *  - فاصل رفيع.
 *  - صف سفلي: خلايا مواصفات متساوية العرض بينها فواصل.
 */
object Overlay {
    fun make(info: WatermarkInfo, p: GlassParams): Bitmap {
        val w = p.barW.toInt()
        val h = p.barH.toInt()
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val hf = h.toFloat()
        val wf = w.toFloat()

        fun paint(size: Float, weight: Int, alpha: Int, spacing: Float = 0f) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(alpha, 255, 255, 255)
            textSize = size
            letterSpacing = spacing
            typeface = Typeface.create(Typeface.DEFAULT, weight, false)
            setShadowLayer(hf * 0.045f, 0f, hf * 0.012f, Color.argb(170, 0, 0, 0))
        }

        fun height(pt: Paint) = pt.fontMetrics.descent - pt.fontMetrics.ascent
        fun drawAt(text: String, x: Float, top: Float, pt: Paint) = c.drawText(text, x, top - pt.fontMetrics.ascent, pt)

        val twoRows = info.stats.isNotEmpty()
        val padX = maxOf(p.radius * 0.9f, wf * 0.045f)
        val c1 = if (twoRows) hf * 0.30f else hf * 0.5f

        // يمين الصف العلوي: التاريخ والوقت في سطر واحد
        var rightW = 0f
        if (info.dateLine.isNotEmpty()) {
            val rt = info.dateLine + "   " + info.timeLine
            val rp = paint(hf * (if (twoRows) 0.11f else 0.17f), 700, 235)
            rightW = rp.measureText(rt)
            drawAt(rt, wf - padX - rightW, c1 - height(rp) / 2f, rp)
        }

        // يسار الصف العلوي: العنوان (يُصغَّر ليناسب) + شارة LIVE
        val livePaint = paint(hf * 0.065f, 700, 255, 0.1f)
        val liveW = if (info.live) livePaint.measureText("LIVE") + hf * 0.12f else 0f
        val maxL = wf - 2 * padX - rightW - hf * 0.15f - (if (info.live) liveW + hf * 0.10f else 0f)
        var size = hf * (if (twoRows) 0.17f else 0.26f)
        var tp = paint(size, 700, 255)
        while (tp.measureText(info.title) > maxL && size > hf * 0.08f) {
            size -= 1f
            tp = paint(size, 700, 255)
        }
        drawAt(info.title, padX, c1 - height(tp) / 2f, tp)
        if (info.live) {
            val bx = padX + tp.measureText(info.title) + hf * 0.07f
            val bh = height(livePaint) + hf * 0.05f
            val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = maxOf(1.5f, hf * 0.009f)
                color = Color.argb(235, 255, 255, 255)
            }
            c.drawRoundRect(RectF(bx, c1 - bh / 2f, bx + liveW, c1 + bh / 2f), bh / 2f, bh / 2f, stroke)
            drawAt("LIVE", bx + (liveW - livePaint.measureText("LIVE")) / 2f, c1 - height(livePaint) / 2f, livePaint)
        }

        if (twoRows) {
            val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.argb(80, 255, 255, 255)
                strokeWidth = maxOf(1.5f, hf * 0.006f)
            }
            val ly = hf * 0.52f
            c.drawLine(padX, ly, wf - padX, ly, line)

            val n = info.stats.size
            val cellW = (wf - 2 * padX) / n
            val lp = paint(hf * 0.066f, 700, 215, 0.12f)
            val gap = hf * 0.03f
            for ((i, st) in info.stats.withIndex()) {
                var vs = hf * 0.12f
                var vp = paint(vs, 700, 255)
                while (vp.measureText(st.second) > cellW * 0.86f && vs > hf * 0.07f) {
                    vs -= 1f
                    vp = paint(vs, 700, 255)
                }
                val blk = height(lp) + gap + height(vp)
                val top = hf * 0.76f - blk / 2f
                val cx = padX + cellW * (i + 0.5f)
                drawAt(st.first, cx - lp.measureText(st.first) / 2f, top, lp)
                drawAt(st.second, cx - vp.measureText(st.second) / 2f, top + height(lp) + gap, vp)
                if (i > 0) {
                    val dx = padX + cellW * i
                    c.drawLine(dx, top, dx, top + blk, line)
                }
            }
        }
        return bmp
    }
}
