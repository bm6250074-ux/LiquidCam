package com.liquidcam.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface

/** يرسم نص الشريط (الاسم، المواصفات، التاريخ) في صورة شفافة بحجم الشريط بالضبط. */
object Overlay {
    fun make(info: WatermarkInfo, p: GlassParams): Bitmap {
        val w = p.barW.toInt()
        val h = p.barH.toInt()
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val hf = h.toFloat()
        val wf = w.toFloat()

        fun paint(size: Float, weight: Int, alpha: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(alpha, 255, 255, 255)
            textSize = size
            typeface = Typeface.create(Typeface.DEFAULT, weight, false)
            setShadowLayer(hf * 0.03f, 0f, hf * 0.01f, Color.argb(72, 0, 0, 0))
        }

        val pad = hf * 0.42f
        val hasRight = info.dateLine.isNotEmpty()
        val rightW = if (hasRight) wf * 0.20f else 0f
        val maxLeft = wf - 2 * pad - rightW

        fun fit(text: String, start: Float, min: Float, weight: Int, alpha: Int): Paint {
            var size = start
            var pt = paint(size, weight, alpha)
            while (pt.measureText(text) > maxLeft && size > min) {
                size -= 1f
                pt = paint(size, weight, alpha)
            }
            return pt
        }

        val tp = fit(info.title, hf * 0.27f, hf * 0.12f, 600, 255)
        val hasSpecs = info.specs.isNotEmpty()
        val sp = if (hasSpecs) fit(info.specs, hf * 0.18f, hf * 0.09f, 500, 235) else null

        val tH = tp.fontMetrics.descent - tp.fontMetrics.ascent
        val sH = sp?.let { it.fontMetrics.descent - it.fontMetrics.ascent } ?: 0f
        val gap = hf * 0.05f
        val total = tH + if (hasSpecs) gap + sH else 0f
        var y = (hf - total) / 2f
        c.drawText(info.title, pad, y - tp.fontMetrics.ascent, tp)
        if (sp != null) {
            y += tH + gap
            c.drawText(info.specs, pad, y - sp.fontMetrics.ascent, sp)
        }

        if (hasRight) {
            val dp = paint(hf * 0.19f, 600, 255)
            val tmp = paint(hf * 0.17f, 500, 225)
            val dH = dp.fontMetrics.descent - dp.fontMetrics.ascent
            val tmH = tmp.fontMetrics.descent - tmp.fontMetrics.ascent
            var ry = (hf - (dH + gap + tmH)) / 2f
            c.drawText(info.dateLine, wf - pad - dp.measureText(info.dateLine), ry - dp.fontMetrics.ascent, dp)
            ry += dH + gap
            c.drawText(info.timeLine, wf - pad - tmp.measureText(info.timeLine), ry - tmp.fontMetrics.ascent, tmp)
        }
        return bmp
    }
}
