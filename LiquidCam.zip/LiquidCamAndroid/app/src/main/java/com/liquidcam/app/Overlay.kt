package com.liquidcam.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface

/**
 * يرسم محتوى اللوحة السفلية (شفافاً) بحجمها بالضبط:
 *  - صف علوي: اسم الهاتف (+ شارة LIVE) وتحته طراز العدسة، وعلى الجهة الأخرى التاريخ والوقت.
 *  - فاصل رفيع.
 *  - صف سفلي: خلايا مواصفات متساوية العرض (البعد البؤري، الفتحة، الغالق، ISO، الحجم) بينها فواصل.
 */
object Overlay {
    fun make(info: WatermarkInfo, p: GlassParams): Bitmap {
        val w = p.barW.toInt()
        val h = p.barH.toInt()
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val hf = h.toFloat()
        val wf = w.toFloat()

        fun paint(size: Float, weight: Int, alpha: Int, spacing: Float = 0f) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(alpha, 255, 255, 255)
            textSize = size
            letterSpacing = spacing
            typeface = Typeface.create(Typeface.DEFAULT, weight, false)
            setShadowLayer(hf * 0.045f, 0f, hf * 0.012f, Color.argb(150, 0, 0, 0))
        }

        fun height(pt: Paint) = pt.fontMetrics.descent - pt.fontMetrics.ascent
        fun drawAt(text: String, x: Float, top: Float, pt: Paint) = c.drawText(text, x, top - pt.fontMetrics.ascent, pt)

        fun fit(text: String, start: Float, min: Float, weight: Int, alpha: Int, maxW: Float, spacing: Float = 0f): Paint {
            var size = start
            var pt = paint(size, weight, alpha, spacing)
            while (pt.measureText(text) > maxW && size > min) {
                size -= 1f
                pt = paint(size, weight, alpha, spacing)
            }
            return pt
        }

        val twoRows = info.stats.isNotEmpty()
        val padX = maxOf(p.radius * 0.9f, wf * 0.04f)
        val gap = hf * 0.03f

        // مركز الصف العلوي
        val row1Center = if (twoRows) hf * 0.29f else hf * 0.5f

        // العمود الأيمن: التاريخ والوقت
        var rightW = 0f
        if (info.dateLine.isNotEmpty()) {
            val dp = paint(hf * (if (twoRows) 0.11f else 0.2f), 600, 255)
            val tp = paint(hf * (if (twoRows) 0.085f else 0.16f), 500, 215)
            rightW = maxOf(dp.measureText(info.dateLine), tp.measureText(info.timeLine))
            val blockH = height(dp) + gap + height(tp)
            var y = row1Center - blockH / 2f
            drawAt(info.dateLine, wf - padX - dp.measureText(info.dateLine), y, dp)
            y += height(dp) + gap
            drawAt(info.timeLine, wf - padX - tp.measureText(info.timeLine), y, tp)
        }

        // شارة LIVE
        val livePaint = paint(hf * (if (twoRows) 0.07f else 0.11f), 700, 255, 0.12f)
        val liveW = if (info.live) livePaint.measureText("LIVE") + hf * 0.12f else 0f
        val liveGap = if (info.live) hf * 0.06f else 0f

        // العمود الأيسر: الاسم + طراز العدسة
        val maxLeft = wf - 2 * padX - rightW - hf * 0.1f - liveW - liveGap
        val titlePt = fit(info.title, hf * (if (twoRows) 0.15f else 0.26f), hf * 0.08f, 700, 255, maxLeft)
        val subPt = if (info.subtitle.isNotEmpty() && twoRows)
            fit(info.subtitle, hf * 0.085f, hf * 0.05f, 500, 205, wf - 2 * padX - rightW - hf * 0.1f) else null
        val leftH = height(titlePt) + (subPt?.let { gap + height(it) } ?: 0f)
        var ly = row1Center - leftH / 2f
        drawAt(info.title, padX, ly, titlePt)
        if (info.live) {
            val bx = padX + titlePt.measureText(info.title) + liveGap
            val bh = height(livePaint) + hf * 0.04f
            val by = ly + (height(titlePt) - bh) / 2f
            val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = maxOf(1.5f, hf * 0.008f)
                color = Color.argb(230, 255, 255, 255)
            }
            c.drawRoundRect(RectF(bx, by, bx + liveW, by + bh), bh / 2f, bh / 2f, stroke)
            drawAt("LIVE", bx + hf * 0.06f, by + hf * 0.02f, livePaint)
        }
        if (subPt != null) {
            ly += height(titlePt) + gap
            drawAt(info.subtitle, padX, ly, subPt)
        }

        if (twoRows) {
            // فاصل أفقي
            val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(70, 255, 255, 255); strokeWidth = maxOf(1.5f, hf * 0.006f) }
            val ly2 = hf * 0.54f
            c.drawLine(padX, ly2, wf - padX, ly2, line)

            // خلايا المواصفات
            val n = info.stats.size
            val cellW = (wf - 2 * padX) / n
            val rowTop = hf * 0.60f
            for ((i, st) in info.stats.withIndex()) {
                val cx = padX + cellW * (i + 0.5f)
                val lp = paint(hf * 0.062f, 500, 170, 0.14f)
                val vp = fit(st.second, hf * 0.125f, hf * 0.07f, 650, 255, cellW * 0.86f)
                val lw = lp.measureText(st.first)
                drawAt(st.first, cx - lw / 2f, rowTop, lp)
                val vw = vp.measureText(st.second)
                drawAt(st.second, cx - vw / 2f, rowTop + height(lp) + gap * 0.8f, vp)
                if (i > 0) {
                    val dx = padX + cellW * i
                    c.drawLine(dx, rowTop, dx, rowTop + height(lp) + gap * 0.8f + height(vp), line)
                }
            }
        }
        return bmp
    }
}
