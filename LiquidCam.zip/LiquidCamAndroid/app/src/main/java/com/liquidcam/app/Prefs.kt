package com.liquidcam.app

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("liquidcam", Context.MODE_PRIVATE)

    fun enabled(c: Context) = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    /** وقت التفعيل: الصور الأقدم منه لا تُعالج (نعالج الصور الجديدة فقط). */
    fun enabledAt(c: Context) = sp(c).getLong("enabledAt", 0L)
    fun setEnabledAt(c: Context, v: Long) = sp(c).edit().putLong("enabledAt", v).apply()

    fun name(c: Context) = sp(c).getString("name", "") ?: ""
    fun setName(c: Context, v: String) = sp(c).edit().putString("name", v).apply()

    fun folder(c: Context) = sp(c).getString("folder", "DCIM/Camera") ?: "DCIM/Camera"
    fun setFolder(c: Context, v: String) = sp(c).edit().putString("folder", v).apply()

    fun specs(c: Context) = sp(c).getBoolean("specs", true)
    fun setSpecs(c: Context, v: Boolean) = sp(c).edit().putBoolean("specs", v).apply()

    fun date(c: Context) = sp(c).getBoolean("date", true)
    fun setDate(c: Context, v: Boolean) = sp(c).edit().putBoolean("date", v).apply()

    fun video(c: Context) = sp(c).getBoolean("video", true)
    fun setVideo(c: Context, v: Boolean) = sp(c).edit().putBoolean("video", v).apply()

    fun lastScan(c: Context) = sp(c).getLong("lastScan", 0L)
    fun setLastScan(c: Context, v: Long) = sp(c).edit().putLong("lastScan", v).apply()

    fun autostartDone(c: Context) = sp(c).getBoolean("autostartDone", false)
    fun setAutostartDone(c: Context, v: Boolean) = sp(c).edit().putBoolean("autostartDone", v).apply()

    fun log(c: Context) = sp(c).getString("log", "") ?: ""
    fun setLog(c: Context, v: String) = sp(c).edit().putString("log", v).apply()
}
