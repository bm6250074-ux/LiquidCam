package com.liquidcam.app

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

/**
 * طبقات تشغيل احتياطية يديرها النظام نفسه حتى لا يتوقف التطبيق:
 *  1) خدمة أمامية + ContentObserver (الأسرع).
 *  2) JobScheduler بمُشغّل محتوى MediaStore: النظام نفسه يوقظ التطبيق عند ظهور صورة جديدة حتى لو قُتلت العملية.
 *  3) WorkManager كل 15 دقيقة: يعيد جدولة (2) ويفحص ما فاته، ويبقى بعد إعادة التشغيل.
 */
object Reliability {
    private const val JOB_ID = 4711
    private const val WORK_NAME = "inlm-periodic-scan"

    fun ensure(ctx: Context) {
        val app = ctx.applicationContext
        schedulePeriodic(app)
        scheduleContentJob(app)
    }

    fun startService(ctx: Context) {
        try {
            ContextCompat.startForegroundService(ctx.applicationContext, Intent(ctx.applicationContext, WatermarkService::class.java))
        } catch (_: Exception) {
            // قد يُمنع التشغيل من الخلفية على أندرويد 12+؛ الطبقتان الأخريان تغطيان ذلك
        }
    }

    fun cancel(ctx: Context) {
        val app = ctx.applicationContext
        WorkManager.getInstance(app).cancelUniqueWork(WORK_NAME)
        app.getSystemService(JobScheduler::class.java).cancel(JOB_ID)
    }

    private fun schedulePeriodic(ctx: Context) {
        val req = PeriodicWorkRequestBuilder<ScanWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, req)
    }

    fun scheduleContentJob(ctx: Context) {
        if (!Prefs.enabled(ctx)) return
        val js = ctx.getSystemService(JobScheduler::class.java)
        val job = JobInfo.Builder(JOB_ID, ComponentName(ctx, MediaJobService::class.java))
            .addTriggerContentUri(
                JobInfo.TriggerContentUri(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    JobInfo.TriggerContentUri.FLAG_NOTIFY_FOR_DESCENDANTS
                )
            )
            .setTriggerContentUpdateDelay(1500)
            .setTriggerContentMaxDelay(5000)
            .build()
        js.schedule(job)
    }
}

/** يوقظه النظام عند ظهور صورة جديدة في MediaStore، حتى لو كانت عملية التطبيق متوقفة. */
class MediaJobService : JobService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onStartJob(params: JobParameters): Boolean {
        if (!Prefs.enabled(this)) return false
        scope.launch {
            try {
                Scanner.scan(applicationContext)
            } catch (_: Throwable) {
            } finally {
                Reliability.scheduleContentJob(applicationContext)
                jobFinished(params, false)
            }
        }
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean {
        Reliability.scheduleContentJob(applicationContext)
        return false
    }
}

/** فحص دوري كل 15 دقيقة + إعادة تأمين كل الطبقات. */
class ScanWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val c = applicationContext
        if (!Prefs.enabled(c)) return Result.success()
        Reliability.scheduleContentJob(c)
        Reliability.startService(c)
        try {
            Scanner.scan(c)
        } catch (_: Throwable) {
        }
        return Result.success()
    }
}
