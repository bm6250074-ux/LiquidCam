package com.liquidcam.app

import android.content.Context
import android.os.Bundle
import android.provider.MediaStore
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File

/** يفحص صور الكاميرا الجديدة في MediaStore ويعالجها. */
object Scanner {
    private val mutex = Mutex()
    private val done = HashSet<String>()

    /** force=true: يعالج أحدث صورة في مجلد الكاميرا فوراً (للتجربة) بغض النظر عن وقت التفعيل. */
    suspend fun scan(ctx: Context, force: Boolean = false, onState: ((String) -> Unit)? = null): Int = mutex.withLock {
        val folder = Prefs.folder(ctx).trim().trim('/')
        val since = Prefs.enabledAt(ctx) - 15_000L
        var processed = 0

        val args = Bundle().apply {
            putString(
                android.content.ContentResolver.QUERY_ARG_SQL_SELECTION,
                "${MediaStore.Images.Media.RELATIVE_PATH} LIKE ? AND ${MediaStore.Images.Media.MIME_TYPE} = ?"
            )
            putStringArray(
                android.content.ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS,
                arrayOf("$folder%", "image/jpeg")
            )
            putString(
                android.content.ContentResolver.QUERY_ARG_SQL_SORT_ORDER,
                "${MediaStore.Images.Media.DATE_ADDED} DESC"
            )
            putInt(android.content.ContentResolver.QUERY_ARG_LIMIT, if (force) 1 else 15)
        }
        val paths = ArrayList<Pair<String, Long>>()
        ctx.contentResolver.query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Images.Media.DATA, MediaStore.Images.Media.DATE_ADDED),
            args, null
        )?.use { c ->
            while (c.moveToNext()) paths.add(c.getString(0) to c.getLong(1) * 1000L)
        }

        for ((path, addedMs) in paths) {
            val file = File(path)
            if (!file.exists()) continue
            if (!force && addedMs < since) continue
            val key = "$path:${file.length()}"
            if (!force && key in done) continue

            // ننتظر حتى يستقر حجم الملف (الكاميرا قد تكون ما زالت تكتب فيه)
            val size1 = file.length()
            delay(800)
            if (file.length() != size1) continue

            onState?.invoke("جارٍ المعالجة: ${file.name}")
            try {
                val ok = ImageProcessor.process(ctx, file)
                if (ok) {
                    processed++
                    Prefs.setLog(ctx, "تمت معالجة ${file.name}")
                }
            } catch (e: Throwable) {
                Prefs.setLog(ctx, "خطأ ${file.name}: ${e.javaClass.simpleName}: ${e.message}")
            }
            done.add(key)
            done.add("$path:${file.length()}")
        }
        onState?.invoke("جاهز")
        processed
    }
}
