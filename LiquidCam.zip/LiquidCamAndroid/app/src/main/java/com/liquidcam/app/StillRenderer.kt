package com.liquidcam.app

import android.graphics.Bitmap
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.opengl.GLES20
import android.opengl.GLUtils
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** يرسم الزجاج السائل فوق صورة ثابتة باستخدام OpenGL ES خارج الشاشة (pbuffer). */
object StillRenderer {
    const val MAX_SIDE = 8192

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(s)
            GLES20.glDeleteShader(s)
            throw RuntimeException("Shader compile failed: $log")
        }
        return s
    }

    private fun link(vs: String, fs: String): Int {
        val v = compile(GLES20.GL_VERTEX_SHADER, vs)
        val f = compile(GLES20.GL_FRAGMENT_SHADER, fs)
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, v)
        GLES20.glAttachShader(p, f)
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("Program link failed: " + GLES20.glGetProgramInfoLog(p))
        return p
    }

    private fun setTex(unit: Int, id: Int, bmp: Bitmap) {
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0 + unit)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, id)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
    }

    /** src يجب أن تكون ARGB_8888 وبالاتجاه الصحيح. تُرجع Bitmap جديدة بنفس الأبعاد. */
    fun render(src: Bitmap, params: GlassParams, overlay: Bitmap, time: Float): Bitmap {
        val w = src.width
        val h = src.height

        val dpy: EGLDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val ver = IntArray(2)
        check(EGL14.eglInitialize(dpy, ver, 0, ver, 1)) { "eglInitialize failed" }

        val cfgAttrs = intArrayOf(
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT,
            EGL14.EGL_NONE
        )
        val cfgs = arrayOfNulls<EGLConfig>(1)
        val num = IntArray(1)
        EGL14.eglChooseConfig(dpy, cfgAttrs, 0, cfgs, 0, 1, num, 0)
        check(num[0] > 0) { "no EGL config" }

        val ctx: EGLContext = EGL14.eglCreateContext(
            dpy, cfgs[0], EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0
        )
        val surf: EGLSurface = EGL14.eglCreatePbufferSurface(
            dpy, cfgs[0], intArrayOf(EGL14.EGL_WIDTH, w, EGL14.EGL_HEIGHT, h, EGL14.EGL_NONE), 0
        )
        try {
            check(EGL14.eglMakeCurrent(dpy, surf, surf, ctx)) { "eglMakeCurrent failed" }

            val prog = link(GlassShaders.VERTEX, GlassShaders.FRAGMENT)
            GLES20.glUseProgram(prog)

            val tex = IntArray(2)
            GLES20.glGenTextures(2, tex, 0)
            setTex(0, tex[0], src)
            setTex(1, tex[1], overlay)
            GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "uTexSampler"), 0)
            GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "uOverlay"), 1)

            for ((name, v) in params.uniforms(time, flipY = -1f, flipSample = 1f)) {
                val loc = GLES20.glGetUniformLocation(prog, name)
                if (loc < 0) continue
                when (v.size) {
                    1 -> GLES20.glUniform1f(loc, v[0])
                    2 -> GLES20.glUniform2f(loc, v[0], v[1])
                    4 -> GLES20.glUniform4f(loc, v[0], v[1], v[2], v[3])
                }
            }

            val quad = floatArrayOf(-1f, -1f, 0f, 1f, 1f, -1f, 0f, 1f, -1f, 1f, 0f, 1f, 1f, 1f, 0f, 1f)
            val fb = ByteBuffer.allocateDirect(quad.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
            fb.put(quad).position(0)
            val aLoc = GLES20.glGetAttribLocation(prog, "aFramePosition")
            GLES20.glEnableVertexAttribArray(aLoc)
            GLES20.glVertexAttribPointer(aLoc, 4, GLES20.GL_FLOAT, false, 0, fb)

            GLES20.glViewport(0, 0, w, h)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

            val buf = ByteBuffer.allocateDirect(w * h * 4).order(ByteOrder.nativeOrder())
            GLES20.glReadPixels(0, 0, w, h, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buf)
            val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            buf.rewind()
            out.copyPixelsFromBuffer(buf)

            GLES20.glDeleteTextures(2, tex, 0)
            GLES20.glDeleteProgram(prog)
            return out
        } finally {
            EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            EGL14.eglDestroySurface(dpy, surf)
            EGL14.eglDestroyContext(dpy, ctx)
            EGL14.eglTerminate(dpy)
        }
    }
}
