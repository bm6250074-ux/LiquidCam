package com.liquidcam.app

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.opengl.GLES20
import android.opengl.GLUtils
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** تأثير Media3 يرسم الزجاج السائل على كل إطار فيديو (Live / Motion Photo). */
@OptIn(UnstableApi::class)
class GlassEffect(private val info: WatermarkInfo) : GlEffect {
    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram =
        GlassShaderProgram(info, useHdr)
}

@OptIn(UnstableApi::class)
class GlassShaderProgram(
    private val info: WatermarkInfo,
    useHdr: Boolean
) : BaseGlShaderProgram(useHdr, 1) {

    private val glProgram: GlProgram = try {
        GlProgram(GlassShaders.VERTEX, GlassShaders.FRAGMENT)
    } catch (e: GlUtil.GlException) {
        throw VideoFrameProcessingException(e)
    }
    private var params: GlassParams? = null
    private var overlayBitmap: Bitmap? = null
    private var overlayTexId = -1

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        val p = GlassParams(inputWidth, inputHeight, info.stats.isEmpty())
        params = p
        overlayBitmap?.recycle()
        overlayBitmap = Overlay.make(info, p)
        overlayTexId = -1
        return Size(inputWidth, inputHeight)
    }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        val p = params ?: return
        try {
            if (overlayTexId == -1) {
                val ids = IntArray(1)
                GLES20.glGenTextures(1, ids, 0)
                overlayTexId = ids[0]
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, overlayTexId)
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
                GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, overlayBitmap, 0)
            }
            glProgram.use()
            glProgram.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
            glProgram.setSamplerTexIdUniform("uOverlay", overlayTexId, 1)
            val time = presentationTimeUs / 1_000_000f
            for ((name, v) in p.uniforms(time, flipY = 1f, flipSample = 0f)) {
                if (v.size == 1) glProgram.setFloatUniform(name, v[0]) else glProgram.setFloatsUniform(name, v)
            }
            glProgram.setBufferAttribute(
                "aFramePosition",
                GlUtil.getNormalizedCoordinateBounds(),
                GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE
            )
            glProgram.bindAttributesAndUniforms()
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            GlUtil.checkGlError()
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e, presentationTimeUs)
        }
    }

    override fun release() {
        super.release()
        try {
            glProgram.delete()
        } catch (_: GlUtil.GlException) {
        }
        overlayBitmap?.recycle()
        overlayBitmap = null
    }
}

@OptIn(UnstableApi::class)
object VideoGlass {
    /** يعالج فيديو الـ Motion Photo ويكتب الناتج في output. يجب أن يعمل من خيط التطبيق الرئيسي (Looper). */
    suspend fun process(ctx: Context, input: File, output: File, info: WatermarkInfo) {
        withContext(Dispatchers.Main) {
            suspendCancellableCoroutine<Unit> { cont ->
                output.delete()
                val transformer = Transformer.Builder(ctx)
                    .setVideoMimeType(MimeTypes.VIDEO_H264)
                    .addListener(object : Transformer.Listener {
                        override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                            if (cont.isActive) cont.resume(Unit)
                        }

                        override fun onError(
                            composition: Composition,
                            exportResult: ExportResult,
                            exportException: ExportException
                        ) {
                            if (cont.isActive) cont.resumeWithException(exportException)
                        }
                    })
                    .build()
                val item = EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(input)))
                    .setEffects(Effects(emptyList(), listOf(GlassEffect(info))))
                    .build()
                cont.invokeOnCancellation { transformer.cancel() }
                transformer.start(item, output.absolutePath)
            }
        }
    }
}
