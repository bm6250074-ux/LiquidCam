package com.liquidcam.app

import android.content.Context
import android.os.Build
import android.provider.Settings
import androidx.exifinterface.media.ExifInterface
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** النصوص التي تظهر داخل شريط الزجاج السائل. */
data class WatermarkInfo(
    val title: String,
    val specs: String,
    val dateLine: String,
    val timeLine: String
) {
    companion object {
        fun deviceName(ctx: Context): String {
            val custom = Prefs.name(ctx).trim()
            if (custom.isNotEmpty()) return custom
            // اسم الجهاز الذي ضبطه المستخدم في إعدادات النظام (مثل "Galaxy S24 Ultra")
            val sys = try {
                Settings.Global.getString(ctx.contentResolver, "device_name")
            } catch (e: Exception) {
                null
            }
            if (!sys.isNullOrBlank()) return sys.trim()
            val maker = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
            val model = Build.MODEL
            return if (model.startsWith(Build.MANUFACTURER, ignoreCase = true)) model else "$maker $model"
        }

        fun from(ctx: Context, exif: ExifInterface?, fallbackMillis: Long): WatermarkInfo {
            val parts = mutableListOf<String>()
            if (exif != null && Prefs.specs(ctx)) {
                val f35 = exif.getAttributeInt(ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM, 0)
                if (f35 > 0) parts.add("$f35 mm")
                val fn = exif.getAttributeDouble(ExifInterface.TAG_F_NUMBER, 0.0)
                if (fn > 0) parts.add("ƒ/" + String.format(Locale.US, "%.1f", fn))
                val et = exif.getAttributeDouble(ExifInterface.TAG_EXPOSURE_TIME, 0.0)
                if (et > 0) {
                    parts.add(if (et < 1.0) "1/${Math.round(1.0 / et)} s" else String.format(Locale.US, "%.1f s", et))
                }
                val iso = exif.getAttributeInt(ExifInterface.TAG_PHOTOGRAPHIC_SENSITIVITY, 0)
                if (iso > 0) parts.add("ISO $iso")
            }

            var date = Date(fallbackMillis)
            exif?.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL)?.let {
                try {
                    SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US).parse(it)?.let { d -> date = d }
                } catch (_: Exception) {
                }
            }
            val showDate = Prefs.date(ctx)
            return WatermarkInfo(
                title = "Shot on " + deviceName(ctx),
                specs = parts.joinToString("  ·  "),
                dateLine = if (showDate) SimpleDateFormat("d MMM yyyy", Locale.ENGLISH).format(date) else "",
                timeLine = if (showDate) SimpleDateFormat("HH:mm", Locale.ENGLISH).format(date) else ""
            )
        }
    }
}
