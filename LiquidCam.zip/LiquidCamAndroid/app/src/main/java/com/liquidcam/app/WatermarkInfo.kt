package com.liquidcam.app

import android.content.Context
import android.os.Build
import android.provider.Settings
import androidx.exifinterface.media.ExifInterface
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** بيانات اللوحة الزجاجية: صف علوي (الاسم/العدسة/التاريخ) وصف سفلي من خلايا المواصفات. */
data class WatermarkInfo(
    val title: String,
    val subtitle: String,
    val dateLine: String,
    val timeLine: String,
    val stats: List<Pair<String, String>>,
    val live: Boolean
) {
    companion object {
        fun deviceName(ctx: Context): String {
            val custom = Prefs.name(ctx).trim()
            if (custom.isNotEmpty()) return custom
            // اسم الجهاز الذي ضبطه المستخدم في إعدادات النظام (مثل "Galaxy S24 Ultra")
            val sys = try {
                Settings.Global.getString(ctx.contentResolver, "device_name")
            } catch (e: Exception) {
                null
            }
            if (!sys.isNullOrBlank()) return sys.trim()
            val maker = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
            val model = Build.MODEL
            return if (model.startsWith(Build.MANUFACTURER, ignoreCase = true)) model else "$maker $model"
        }

        fun from(
            ctx: Context,
            exif: ExifInterface?,
            fallbackMillis: Long,
            width: Int,
            height: Int,
            live: Boolean
        ): WatermarkInfo {
            val stats = mutableListOf<Pair<String, String>>()
            var lens = ""
            if (exif != null && Prefs.specs(ctx)) {
                val f35 = exif.getAttributeInt(ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM, 0)
                if (f35 > 0) stats.add("FOCAL" to "$f35 mm")
                val fn = exif.getAttributeDouble(ExifInterface.TAG_F_NUMBER, 0.0)
                if (fn > 0) stats.add("APERTURE" to "ƒ/" + String.format(Locale.US, "%.1f", fn))
                val et = exif.getAttributeDouble(ExifInterface.TAG_EXPOSURE_TIME, 0.0)
                if (et > 0) {
                    stats.add("SHUTTER" to (if (et < 1.0) "1/${Math.round(1.0 / et)}" else String.format(Locale.US, "%.1f s", et)))
                }
                val iso = exif.getAttributeInt(ExifInterface.TAG_PHOTOGRAPHIC_SENSITIVITY, 0)
                if (iso > 0) stats.add("ISO" to "$iso")
                val mp = width.toLong() * height / 1_000_000.0
                if (mp >= 0.5) stats.add("SIZE" to String.format(Locale.US, "%.0f MP", mp))
                lens = exif.getAttribute(ExifInterface.TAG_LENS_MODEL)?.trim() ?: ""
            }

            var date = Date(fallbackMillis)
            exif?.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL)?.let {
                try {
                    SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US).parse(it)?.let { d -> date = d }
                } catch (_: Exception) {
                }
            }
            val showDate = Prefs.date(ctx)
            return WatermarkInfo(
                title = "Shot on " + deviceName(ctx),
                subtitle = lens,
                dateLine = if (showDate) SimpleDateFormat("d MMM yyyy", Locale.ENGLISH).format(date) else "",
                timeLine = if (showDate) SimpleDateFormat("HH:mm", Locale.ENGLISH).format(date) else "",
                stats = stats,
                live = live
            )
        }
    }
}
