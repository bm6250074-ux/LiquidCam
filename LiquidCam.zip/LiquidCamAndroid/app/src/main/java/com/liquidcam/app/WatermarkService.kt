package com.liquidcam.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.database.ContentObserver
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** خدمة تعمل في الخلفية وتراقب صور الكاميرا الجديدة لإضافة العلامة المائية تلقائياً. */
class WatermarkService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var observer: ContentObserver

    private val scanRunnable = Runnable {
        scope.launch { Scanner.scan(this@WatermarkService) { updateNotification(it) } }
    }

    // فحص دوري احتياطي كل 45 ثانية في حال فاتت الخدمةَ إشعاراتُ النظام (للاستقرار)
    private val periodic = object : Runnable {
        override fun run() {
            scope.launch { Scanner.scan(this@WatermarkService) { updateNotification(it) } }
            handler.postDelayed(this, 45_000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("lc", "IN-LiquidMark", NotificationManager.IMPORTANCE_LOW)
        )
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, 1, buildNotification("جاهز — يراقب صور الكاميرا"), type)

        observer = object : ContentObserver(handler) {
            override fun onChange(selfChange: Boolean) {
                handler.removeCallbacks(scanRunnable)
                handler.postDelayed(scanRunnable, 1500)
            }
        }
        contentResolver.registerContentObserver(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, observer)
        handler.postDelayed(periodic, 5_000)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        contentResolver.unregisterContentObserver(observer)
        handler.removeCallbacks(scanRunnable)
        handler.removeCallbacks(periodic)
        scope.cancel()
        super.onDestroy()
    }

    private fun buildNotification(text: String): Notification =
        Notification.Builder(this, "lc")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("IN-LiquidMark")
            .setContentText(text)
            .setOngoing(true)
            .build()

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(1, buildNotification(text))
    }
}
